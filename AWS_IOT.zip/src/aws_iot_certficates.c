/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = R"(-----BEGIN CERTIFICATE-----
MIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF
ADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6
b24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL
MAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv
b3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj
ca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM
9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw
IFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6
VOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L
93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm
jgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC
AYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA
A4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI
U5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs
N+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv
o/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU
5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy
rqXRfboQnoZsG4q5WTP468SQvvG5
-----END CERTIFICATE-----)";

const char certificate_pem_crt[] = R"(-----BEGIN CERTIFICATE-----
MIIDWTCCAkGgAwIBAgIUd9SEk4T8BNy/4Z2y7JP3YCftfQgwDQYJKoZIhvcNAQEL
BQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g
SW5jLiBMPVNlYXR0bGUgU1Q9V2FzaGluZ3RvbiBDPVVTMB4XDTIwMDcyNzEyMTAx
M1oXDTQ5MTIzMTIzNTk1OVowHjEcMBoGA1UEAwwTQVdTIElvVCBDZXJ0aWZpY2F0
ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOCK5u4PdC7L7RO7To5e
pzCvSPkoRkhULXUZ+H8WfltW6TFc+Bgpnv1zGk5tH0LBmLcpHJntaEGoiFI3qUjj
rC9HWlWTnHKg6l0NcKyj5xfw3ywfFUCVjCUjIq1C1lEtKX0chfMHmDqkPlDqysKc
P8fWvRlI8vGapQ7EWsp+yOkEdsTBdikpO0ARVLznL8a26Sbluv69jrfVbdcld2nG
uqZG0s9k0QjzFUJ2iqiqdaMCh6Z5u3i2Zemy9FrmXduu/wBSuNmWpMjWj5v//Prf
+AWJdK2DCrLwE4QcqAX+0jOH8p5F90BTgPryUWotlMBJpl5kcXGbRO9w2N+X8KbT
KzcCAwEAAaNgMF4wHwYDVR0jBBgwFoAUwNkVUuZliojXm9a6qrq6vm5oO7EwHQYD
VR0OBBYEFFkfUwC7szIvMHDicEqzZCnXpjhBMAwGA1UdEwEB/wQCMAAwDgYDVR0P
AQH/BAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQBxRRBu/9F74uI8mFJYAFU/HIam
PRYNFj2r/pzpels72tGDyMk+q9ZSjncI2k7ebmqU7KLx5RPWaLu2s+k8OX2DQzcR
SRkfczkeQ9m5KTKac5JeO9/gHsk9mt7MRbZhr5Y2lnf8/L4ZiHcL4wAJJa+mBd5H
cHaTlLUguWqCTBcbqDHKjTKS9tPmBnLUfq0iZ5BhlfNA1LDJFAlg5egrKPqJNfb9
di4EFb2dMAnxiFyMstxc9yAC+/VCtyIc64jNkX0MSaP3T5+2MX9bbBSR0fE8xbJe
/uZ7ZsIo5j/quiTiQMezEOdFLLqnnEe6Bdr2d2aEEBCYjXRTnln/I2BaiYNO
-----END CERTIFICATE-----)";

const char private_pem_key[] = R"(-----BEGIN RSA PRIVATE KEY-----
MIIEpAIBAAKCAQEA4Irm7g90LsvtE7tOjl6nMK9I+ShGSFQtdRn4fxZ+W1bpMVz4
GCme/XMaTm0fQsGYtykcme1oQaiIUjepSOOsL0daVZOccqDqXQ1wrKPnF/DfLB8V
QJWMJSMirULWUS0pfRyF8weYOqQ+UOrKwpw/x9a9GUjy8ZqlDsRayn7I6QR2xMF2
KSk7QBFUvOcvxrbpJuW6/r2Ot9Vt1yV3aca6pkbSz2TRCPMVQnaKqKp1owKHpnm7
eLZl6bL0WuZd267/AFK42ZakyNaPm//8+t/4BYl0rYMKsvAThByoBf7SM4fynkX3
QFOA+vJRai2UwEmmXmRxcZtE73DY35fwptMrNwIDAQABAoIBADGR+JEtkDSUiG4G
t7zuYHJ6/90hawKksrRbW2STDqoTcb+YCp0q8xJ4yqHtrS0LmC83QD0rEA0Oq6ma
6CBTQrvdQLALukoEBDkusmUqeeXrIxmWcxai7SF1tD4Tt0SMd9BK77dLQewQPkGW
09RKsjnnyi8+z4NO5IlyB6kUfD4UeFQl3uwGi5pQ6Kc/YUIObEmHihM02Vp5Z5wf
xlQZfSbyyTP2szvb4reDAqf1plTL2UsAv01trPCHV6s8/ldU5HFsS9DRf/FSWjlb
cfSGDU/0xyVBKWbX4h8op6Pl3mrrL5Ospnoz3+UZthdzWBJlJxGSlllSVF4774sa
9timCOECgYEA88c7sGbLp/qucr8R4MHhTPSEArJFh4VdByj4/Jx6SOXjfB80U5H8
WttfKHk3XuDIE16cP+pTH57ZgHRtm8h+486ekVxCn15TAKFg4XtAkRo9cHvS/lyE
Yidk0sQQiO2J3njRm0Q6/5/fEenItWMDD6jjrNIgDMWxX/+3uk0Zd90CgYEA68zK
BJNX/ZAL/KvxnEgmHN65/FZli6H3RGW1h/f69T9KxsALjwr5TSJEAWF7wQEuYptY
hdnjsVa8JcmnX0PBIc5kA02H0P3Cjtey7+aIObpaZmV9rceR906DerlgIBE8P1ci
yUjY1vqB0NtRIlv65v4XPblNidRiuRYL6vreaCMCgYEAgUgzu4WIk/k58tip3oxz
s6ApMlTg0tJDV7y+7xj9MRPZ5MWXtopBTt3wRUKjvslu0fbm3m6izq4roxgb2PYn
dSDqryRCoMohMsBi5LG8uDc2RiUk7IicHIHP0obwTe3LpBRm9PTmZRKf9pwJOUjd
IrzqoYh+PsfJHaQ8B61DyHECgYEA6nf9XWViNllZAgu7uUoo08ZJK/iBCsKoDFQS
mTxlSB6CbXUjST6BPUjYVIMpunZBOH3+HULXXUzA09Zb3qeR0NrYqkwaxB7Aqqcj
X9ddGAIMyAsdWIK8yyxAIvVX9ysMPHOZvIr6S3JXSWX7nG3X5H8+fvrWdjpBXIfm
m+aO5v8CgYAaNUJuw7SImDrHfctL3YqJazILFvANweSMas8I9uRDAwCj1LRzftsk
ra7Um2Aw7Ea6V00u66bXp54cWGhy5ffTuOCQaS6OuPCqMqeppoSIF7enS9lEyzbn
e9se0Tm+YqltWxVzXVzCiWZJwzG7xAVkaTxtywUSKPOhYqNIhfaNcA==
-----END RSA PRIVATE KEY-----)";


#ifdef __cplusplus
}
#endif
